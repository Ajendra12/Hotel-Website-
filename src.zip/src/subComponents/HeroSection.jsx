import React from 'react'

const HeroSection = () => {
  return (
    <>
    <section id= 'hero'>
        <h1>BE OUR GUEST</h1>
        <p>LIVE LIKE A KING IN OUR BEST HOUSES</p>
    </section>
    
    </>
  )
}

export default HeroSection