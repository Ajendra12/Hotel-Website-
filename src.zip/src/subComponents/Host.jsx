import React from "react";

const Host = () => {
  return (
    <>
      <section id='host'>
          <div className="container">
            <p>BECOME A HOST</p>
            <h3>Become a host</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi nam facilis odit officiis quod fuga, aut expedita nostrum perferendis molestiae.</p>
            <button>JOIN TODAY</button>
          </div>
        </section> 
    </>
  )
}

export default Host
